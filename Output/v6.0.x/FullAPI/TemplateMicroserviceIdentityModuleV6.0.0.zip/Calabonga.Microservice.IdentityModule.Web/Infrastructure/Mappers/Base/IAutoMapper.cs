﻿namespace $safeprojectname$.Infrastructure.Mappers.Base;

/// <summary>
/// The stub for reflection helper profiles registrations
/// </summary>
public interface IAutoMapper { }