﻿namespace $safeprojectname$.Infrastructure.Factories.Base
{
    /// <summary>
    /// Just a stub for <see cref="ViewModelFactory{TEntity,TCreateViewModel,TUpdateViewModel}"/>see
    /// </summary>
    public interface IViewModel { }
}