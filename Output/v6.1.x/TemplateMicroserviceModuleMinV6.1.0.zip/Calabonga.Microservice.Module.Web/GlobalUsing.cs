﻿//global using $safeprojectname$.Definitions.Identity;
//global using $safeprojectname$.Endpoints.Base;
//global using $safeprojectname$.Endpoints.EventItemEndpoints.Queries;
//global using $safeprojectname$.Endpoints.EventItemEndpoints.ViewModels;
//global using Calabonga.OperationResults;
//global using Calabonga.UnitOfWork;
//global using MediatR;
//global using FluentValidation;
//global using AutoMapper;
//global using $ext_projectname$.Domain;
//global using $safeprojectname$.Definitions.Mapping;
//global using Microsoft.AspNetCore.Authorization;
//global using Microsoft.AspNetCore.Mvc;
//global using $safeprojectname$.Endpoints.ProfileEndpoints.Queries;
//global using $safeprojectname$.Endpoints.ProfileEndpoints.ViewModels;
//global using $safeprojectname$.Application.Services;
//global using $ext_projectname$.Infrastructure;
//global using Calabonga.Microservices.Core;
//global using IdentityModel;
//global using System.Security.Claims;
//global using Serilog;
//global using System.Text.Json;

namespace $safeprojectname$
{
}