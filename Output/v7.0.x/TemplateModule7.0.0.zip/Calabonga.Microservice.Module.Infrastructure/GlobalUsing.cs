﻿global using $ext_projectname$.Domain;
global using $ext_projectname$.Domain.Base;
global using Microsoft.AspNetCore.Identity;
global using Microsoft.Extensions.DependencyInjection;