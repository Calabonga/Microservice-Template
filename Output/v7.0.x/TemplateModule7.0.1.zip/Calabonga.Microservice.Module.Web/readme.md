﻿# About

| Name         | Description                                |
| ------------ | ------------------------------------------ |
| Name         | Microservice Template for ASP.NET Core API |
| Author       | Calabonga SOFT © 2005-2022 Calabonga SOFT  |
| Created Date | 2019-04-19                                 |

# Versions

Nimble Framework Templates build on .NET 7.0. That`s why it have the same major version. But the all improvements will increment minor versions. 
Current version: 7.0.0

# Contacts

You can contact me by using the next opportunities:

* Blog: https://www.calabonga.net
* GitHub: https://github.com/Calabonga
* Zen: https://dzen.ru/calabonga
* YouTube: https://youtube.com/sergeicalabonga

# Description:

This template implements Web API functionality using minmal API feature from NET 7.0