﻿namespace $safeprojectname$.Base
{
    /// <summary>
    /// Represents ViewModel for CRUD controller
    /// </summary>
    public interface IViewModel { }
}