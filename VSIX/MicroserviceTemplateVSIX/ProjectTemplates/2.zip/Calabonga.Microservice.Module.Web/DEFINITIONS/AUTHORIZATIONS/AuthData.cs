﻿using OpenIddict.Server.AspNetCore;

namespace $safeprojectname$.Definitions.Authorizations;

public static class AuthData
{
    public const string AuthSchemes = OpenIddictServerAspNetCoreDefaults.AuthenticationScheme;
}