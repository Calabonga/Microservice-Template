﻿using $safeprojectname$.Application.Messaging.EventItemMessages.ViewModels;
using $safeprojectname$.Definitions.Mediator.Base;
using Calabonga.Results;
using Calabonga.UnitOfWork;
using MediatR;

namespace $safeprojectname$.Definitions.Mediator;

public class LogPostTransactionBehavior : TransactionBehavior<IRequest<Operation<EventItemViewModel>>, Operation<EventItemViewModel>>
{
    public LogPostTransactionBehavior(IUnitOfWork unitOfWork) : base(unitOfWork) { }
}