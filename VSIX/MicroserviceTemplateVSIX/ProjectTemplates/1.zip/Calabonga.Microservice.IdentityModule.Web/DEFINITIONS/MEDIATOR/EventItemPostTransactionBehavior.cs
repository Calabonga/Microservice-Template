﻿using $safeprojectname$.Application.Messaging.EventItemMessages.ViewModels;
using $safeprojectname$.Definitions.Mediator.Base;
using Calabonga.Results;
using Calabonga.UnitOfWork;
using MediatR;

namespace $safeprojectname$.Definitions.Mediator;

public class EventItemPostTransactionBehavior(IUnitOfWork unitOfWork)
    : TransactionBehavior<IRequest<Operation<EventItemViewModel>>, Operation<EventItemViewModel>>(unitOfWork);