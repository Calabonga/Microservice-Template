﻿using $ext_projectname$.Entities;
using Calabonga.Microservices.Core.Validators;

namespace $safeprojectname$.Infrastructure.Validations
{
    /// <summary>
    /// Validator for entity Log
    /// </summary>
    public class LogValidator : EntityValidator<Log>
    {
        
    }
}